# KIF portal launcher v9 (2026-11-24)
# Opens the portal as an app window. If Chrome opens the new window minimized
# (seen with Chrome 158 when Chrome is already running), it restores it and brings it to the front.
param([string]$exe, [string]$url)
Add-Type -TypeDefinition @"
using System; using System.Text; using System.Collections.Generic; using System.Runtime.InteropServices;
public static class KifWin {
  delegate bool EP(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] static extern bool EnumWindows(EP f, IntPtr l);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  public static List<IntPtr> Find(string[] keys) {
    var r = new List<IntPtr>();
    EnumWindows((h, l) => {
      if (!IsWindowVisible(h)) return true;
      var s = new StringBuilder(512); GetWindowText(h, s, 512); var t = s.ToString();
      foreach (var k in keys) { if (t.Contains(k)) { r.Add(h); break; } }
      return true; }, IntPtr.Zero);
    return r;
  }
}
"@
# window title "<hangul>on" (portal name) or the bare address while loading
$keys = @(([string][char]0xD55C + [char]0xBCF4 + [char]0xAE08 + 'on'), 'bluewind1124-ui.github.io')
$before = @{}
foreach ($h in [KifWin]::Find($keys)) { $before[[string]$h] = 1 }
Start-Process -FilePath $exe -ArgumentList "--app=$url"
for ($i = 0; $i -lt 60; $i++) {
  Start-Sleep -Milliseconds 250
  $new = @([KifWin]::Find($keys) | Where-Object { -not $before.ContainsKey([string]$_) })
  if ($new.Count -gt 0) {
    Start-Sleep -Milliseconds 400
    foreach ($h in $new) {
      if ([KifWin]::IsIconic($h)) { [void][KifWin]::ShowWindow($h, 9) }
      [void][KifWin]::SetForegroundWindow($h)
    }
    break
  }
}
