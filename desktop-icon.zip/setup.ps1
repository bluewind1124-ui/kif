﻿# 한보금on 활동지원 - PC 바탕화면 아이콘 만들기 (v8: 투명 배경 은색 엠블럼 · 앱 창으로 열기)
$ErrorActionPreference = 'Stop'
$name = '한보금on 활동지원'
$url  = 'https://bluewind1124-ui.github.io/kif/'
$dir  = Join-Path $env:LOCALAPPDATA 'KIFPortal'
New-Item -ItemType Directory -Force -Path $dir | Out-Null
# 새 그림이 바로 보이도록 버전 붙은 이름으로 복사하고 예전 아이콘 파일은 지운다
Get-ChildItem -Path $dir -Filter '*.ico' -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
$ico  = Join-Path $dir 'kif-portal-v8.ico'
Copy-Item -Force (Join-Path $PSScriptRoot 'kif-portal.ico') $ico
$desk = [Environment]::GetFolderPath('Desktop')

# 예전 아이콘(옛 이름 · .url 방식)은 지운다
foreach ($o in @(($name + '.url'), '한국보험금융 교육지원 포털.url', '한국보험금융 교육지원 포털.lnk')) {
  $old = Join-Path $desk $o
  if (Test-Path $old) { Remove-Item -Force $old }
}

# 평소 쓰는 브라우저를 찾는다 (로그인·AI 등록 정보가 그 브라우저에 있으므로)
$progId = ''
try { $progId = (Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\Shell\Associations\UrlAssociations\https\UserChoice' -ErrorAction Stop).ProgId } catch {}
function Find-Exe($rel) {
  foreach ($b in @($env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:LOCALAPPDATA)) {
    if ($b) { $p = Join-Path $b $rel; if (Test-Path $p) { return $p } }
  }
  return $null
}
$chrome = Find-Exe 'Google\Chrome\Application\chrome.exe'
$edge   = Find-Exe 'Microsoft\Edge\Application\msedge.exe'
$exe = $null
if ($progId -like 'ChromeHTML*' -and $chrome) { $exe = $chrome }
elseif ($progId -like 'MSEdgeHTM*' -and $edge) { $exe = $edge }

# 바로가기(.lnk): 크롬·엣지면 주소창 없는 「앱 창」으로, 그 밖의 브라우저면 평소 브라우저로 연다
$lnk = Join-Path $desk ($name + '.lnk')
$ws  = New-Object -ComObject WScript.Shell
$sc  = $ws.CreateShortcut($lnk)
if ($exe) {
  $sc.TargetPath = $exe
  $sc.Arguments  = "--app=$url"
  $how = '앱 창(주소창 없음)'
} else {
  $sc.TargetPath = Join-Path $env:WINDIR 'explorer.exe'
  $sc.Arguments  = $url
  $how = '평소 쓰시는 브라우저'
}
$sc.IconLocation = "$ico,0"
$sc.Description  = $name
$sc.Save()

# 시작 메뉴에도 같은 아이콘
try {
  $sm = Join-Path ([Environment]::GetFolderPath('Programs')) ($name + '.lnk')
  Copy-Item -Force $lnk $sm
} catch {}

# 아이콘 그림 새로 고침
try { & (Join-Path $env:WINDIR 'System32\ie4uinit.exe') -show } catch {}

Write-Host ''
Write-Host "바탕화면에 '$name' 아이콘을 만들었습니다. ($how 으로 열립니다)" -ForegroundColor Green
Write-Host '아이콘 그림이 바로 안 바뀌면 바탕화면에서 F5(새로 고침)를 누르세요.'
