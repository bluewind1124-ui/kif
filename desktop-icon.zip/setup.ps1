﻿# 한보금on 활동지원 - 바탕화면 아이콘 만들기 (v4: 주소 kif로 변경)
$ErrorActionPreference = 'Stop'
$name = '한보금on 활동지원'
$url  = 'https://bluewind1124-ui.github.io/kif/'
$dir  = Join-Path $env:LOCALAPPDATA 'KIFPortal'
New-Item -ItemType Directory -Force -Path $dir | Out-Null
$ico  = Join-Path $dir 'kif-portal.ico'
Copy-Item -Force (Join-Path $PSScriptRoot 'kif-portal.ico') $ico
$desk = [Environment]::GetFolderPath('Desktop')

# 예전 아이콘(옛 이름 · .url 방식)은 지운다
foreach ($o in @(($name + '.url'), '한국보험금융 교육지원 포털.url', '한국보험금융 교육지원 포털.lnk')) {
  $old = Join-Path $desk $o
  if (Test-Path $old) { Remove-Item -Force $old }
}

# 바로가기(.lnk): 기본 인터넷 브라우저로 포털을 연다
$lnk = Join-Path $desk ($name + '.lnk')
$ws  = New-Object -ComObject WScript.Shell
$sc  = $ws.CreateShortcut($lnk)
$sc.TargetPath   = Join-Path $env:WINDIR 'explorer.exe'
$sc.Arguments    = $url
$sc.IconLocation = "$ico,0"
$sc.Description  = $name
$sc.Save()

# 아이콘 그림 새로 고침
try { & (Join-Path $env:WINDIR 'System32\ie4uinit.exe') -show } catch {}

Write-Host ''
Write-Host "바탕화면에 '$name' 아이콘을 만들었습니다." -ForegroundColor Green
Write-Host '아이콘 그림이 바로 안 바뀌면 바탕화면에서 F5(새로 고침)를 누르세요.'
