﻿# 한국보험금융 교육지원 포털 - 바탕화면 아이콘 만들기
$ErrorActionPreference = 'Stop'
$name = '한국보험금융 교육지원 포털'
$url  = 'https://bluewind1124-ui.github.io/mirae-bohum/'
$dir  = Join-Path $env:LOCALAPPDATA 'KIFPortal'
New-Item -ItemType Directory -Force -Path $dir | Out-Null
$ico  = Join-Path $dir 'kif-portal.ico'
Copy-Item -Force (Join-Path $PSScriptRoot 'kif-portal.ico') $ico
$desk = [Environment]::GetFolderPath('Desktop')
$lnk  = Join-Path $desk ($name + '.url')
$text = "[InternetShortcut]`r`nURL=$url`r`nIconFile=$ico`r`nIconIndex=0`r`n"
[IO.File]::WriteAllText($lnk, $text, [Text.Encoding]::Default)
Write-Host ''
Write-Host "바탕화면에 '$name' 아이콘을 만들었습니다." -ForegroundColor Green
